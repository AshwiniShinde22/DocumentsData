package com.bookstore.demo.documentrepo;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bookstore.demo.model.Document;
@Repository
public interface DocumentRepository extends JpaRepository<Document, Long> {
	
	@Query("SELECT new  Document(d.id,d.name,d.size)FROM Document d ORDER BY d.uploadTime DESC")
	public List<Document> findAll(Page<Document> page);

}
